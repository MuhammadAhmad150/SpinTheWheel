using UnityEngine;

public class DrawArc : MonoBehaviour
{
    public float radius = 1.0f;
    public Vector3 origin=Vector3.zero;

    private LineRenderer lineRenderer;

    void Start()
    {
        lineRenderer = GetComponent<LineRenderer>();
        if (lineRenderer == null)
        {
            lineRenderer = gameObject.AddComponent<LineRenderer>();
            lineRenderer.material = new Material(Shader.Find("Sprites/Default"));
            lineRenderer.startColor = Color.black;
            lineRenderer.endColor = Color.black;
            lineRenderer.startWidth = 0.1f;
            lineRenderer.endWidth = 0.1f;
        }
    }

    void Update()
    {
        DrawCircle();
    }

    void DrawCircle()
    {
        int segments = 360;
        lineRenderer.positionCount = segments + 1;
        for (int i = 0; i <= segments; i++)
        {
            float angle = i * Mathf.PI * 2 / segments;
            float x = origin.x + Mathf.Cos(angle) * radius;
            float y = origin.y;
            float z = origin.z + Mathf.Sin(angle) * radius;
            Vector3 pos = new Vector3(x, y, z);
            lineRenderer.SetPosition(i, pos);
        }
    }
}
