using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;


[System.Serializable]
public class Names
{
    public string[] names;
}

[System.Serializable]
public class Circles
{
    public string circleName;
    public float startingAngle;
    public float endingAngle;
}

public class CircleDivision : MonoBehaviour
{
    public GameObject Canvas;
    public float maxRotationSpeed = 510f; // Maximum rotation 
    public float rotationDeceleration = 90f; // Deceleration 
    public float totalAngleRotated = 0f;

    List<string> updatedNames = new List<string>{};
    List<Circles> circlesList = new List<Circles>();

    public int numSegments = 100;      
    public float radius = 5f;         

    private void Start()
    {  
        //Debug.Log("Start()AGAIN");
        maxRotationSpeed = UnityEngine.Random.Range(480f, 555f);
        //Debug.Log("Max="+maxRotationSpeed);
        string filePath = Application.persistentDataPath + "/names.json";

        Names deserializedNameData=null;
        
        // Check if the file exists before attempting to read from it
        if (File.Exists(filePath))
        {
            // Read the JSON data from the file 
            //Read ALLLLLL
            string jsonString = File.ReadAllText(filePath);

            // Deserialize the JSON data into a NameData instance
            deserializedNameData = JsonUtility.FromJson<Names>(jsonString);
            //Debug.Log(jsonString);
            // Print the deserialized names to the console

            //ANGLE PRINT
            float angleSize=360f/deserializedNameData.names.Length;
            //Debug.Log("angleSize= "+angleSize);
            float StartAddress=0;
            float EndAddress=angleSize;
            foreach (string nam in deserializedNameData.names)
            {
                circlesList.Add(new Circles { circleName = nam, startingAngle = StartAddress, endingAngle = EndAddress });
                //Debug.Log("NAME: " + nam);
                StartAddress+=angleSize;
                EndAddress+=angleSize;
                
            }//TICKTICKKKK
            //Printing
            int i=0;
            //CREATION!
            int numberOfElements = circlesList.Count;
            Color orange=new Color(1f, 0.647f, 0f);
            foreach (var circle in circlesList)
            {
                
               // Debug.Log($"Circle: {circle.circleName}, Starting Angle: {circle.startingAngle}, Ending Angle: {circle.endingAngle}");
                if(i==numberOfElements-1)
                 {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "white", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==0)
                    {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "red", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==1)
                   {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "blue", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==2)
                   {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "yellow", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==3)
                   {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "green", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==4)
                    {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "purple", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==5)
                   {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "red1", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==6)
                   {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "blue1", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==7)
                   {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "yellow1", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==8)
                   {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "green1", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
                else if(i%10==9)
                   {CreateCircularSegment(circle.startingAngle, circle.endingAngle, "purple1", (circle.startingAngle+ circle.endingAngle)/2, circle.circleName);}
 
                i++;
            }
            //Debug.Log("MA=="+numberOfElements);
            if(numberOfElements==1)
            {
                Canvas.SetActive(true);
            }
            //Angles PRINTINGDONEEE
            // foreach (var circle in circlesList)
            // {
            //     Debug.Log($"Circle: {circle.circleName}, Starting Angle: {circle.startingAngle}, Ending Angle: {circle.endingAngle}");
            // }
        }
        else
        {
            Debug.LogWarning("JSON file not found: " + filePath);
        }
        //Debug.Log("No.of Names= "+deserializedNameData.names.Length);
    }
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            totalAngleRotated=0;
            StartCoroutine(SpinWheel());
        }
        if (Input.touchCount > 0)
        {
            totalAngleRotated=0;
            StartCoroutine(SpinWheel());
        }
    }
    private IEnumerator SpinWheel()
    {
        float rotationSpeed = maxRotationSpeed;

        while (rotationSpeed>0)
        {
            // forward for anticlockwise
            transform.Rotate(Vector3.back, rotationSpeed * Time.deltaTime);
            totalAngleRotated += rotationSpeed * Time.deltaTime;

            rotationSpeed -= rotationDeceleration * Time.deltaTime;
            rotationSpeed = Mathf.Max(0f, rotationSpeed);
            
            yield return null;
        }
        isWinner();
    } 
    //private void CreateCircularSegment(float startAngle, float endAngle, Color segmentColor,float angle, string text)
    private void CreateCircularSegment(float startAngle, float endAngle, string SegmentColourName,float angle, string text)
    {
        
        GameObject segmentObject = new GameObject("CircularSegment");
        segmentObject.transform.SetParent(transform); // Set as child of the current GameObject

        MeshFilter meshFilter = segmentObject.AddComponent<MeshFilter>();
        MeshRenderer meshRenderer = segmentObject.AddComponent<MeshRenderer>();
        Mesh mesh = new Mesh();

        int verticesCount = numSegments + 2;
        Vector3[] vertices = new Vector3[verticesCount];
        int[] triangles = new int[numSegments * 3];

        //
        vertices[0] = Vector3.zero;


        float angleIncrement = (endAngle - startAngle) / numSegments;
        float currentAngle = startAngle;

        for (int i = 1; i < verticesCount; i++)
        {
            float x = Mathf.Sin(currentAngle * Mathf.Deg2Rad) * radius;
            float y = Mathf.Cos(currentAngle * Mathf.Deg2Rad) * radius;
            vertices[i] = new Vector3(x, y, 0f);

            currentAngle += angleIncrement;
        }

        // Create triangles for the segment
        for (int i = 0; i < numSegments; i++)
        {
            triangles[i * 3] = 0;
            triangles[i * 3 + 1] = i + 1;
            triangles[i * 3 + 2] = i + 2;
        }

        mesh.vertices = vertices;
        mesh.triangles = triangles;
        meshFilter.mesh = mesh;
        //Color redColor = new Color(1f, 0f, 0f);
        //meshRenderer.material.color = redColor;
        
        //working meshRenderer.material.color = segmentColor;
        //string SegmentColourName="red";
        {
            Material redMaterial = Resources.Load<Material>(SegmentColourName);
            if (redMaterial != null)
            {
                Renderer renderer = GetComponent<Renderer>();
                renderer.material = redMaterial;
            }
            else
            {
                Debug.LogError("Failed to load the material from Resources.");
            }
             meshRenderer.material=redMaterial;
        }
       
        //{Material segmentMaterial = new Material(Shader.Find("Standard"));
        //segmentMaterial.color = segmentColor;
        // meshRenderer.material=segmentMaterial;}
        
        // Calculate the middle angle of the segment
        float middleAngle = (startAngle + endAngle) * 0.5f;

        // TextField
        {
            GameObject textObject = new GameObject("TextAlongAngle");
            textObject.transform.SetParent(segmentObject.transform); // Set as child of the segment GameObject
            textObject.transform.localScale = new Vector3(1f, 1f, 1f);

            TMP_Text textMesh = textObject.AddComponent<TextMeshPro>();
            textMesh.text = text;
            textMesh.fontSize = 4;
            //textMesh.color = Color.black;
            textMesh.alignment = TextAlignmentOptions.Center;

            // Calculate position for the text along the middle angle of the segment
            float x = Mathf.Sin(middleAngle * Mathf.Deg2Rad) * (radius * 0.6f); // Adjust 0.6f to control the position of the text within the segment
            float y = Mathf.Cos(middleAngle * Mathf.Deg2Rad) * (radius * 0.6f);

            textObject.transform.localPosition = new Vector3(x, y, 0f);
            Vector3 rotationVector = new Vector3(0f, 0f, angle);
            //textObject.transform.rotation = Quaternion.Euler(rotationVector);
            //textObject.transform.LookAt(Vector3.zero, Vector3.forward);
        
        }
    }
    private int CalculateFontSize(TextMesh textMesh, float radius)
    {
        // Calculate the size of the textMesh based on the specified radius
        int fontSize = 1;
        while (fontSize < 100)
        {
            textMesh.fontSize = fontSize;
            Vector3 size = textMesh.GetComponent<Renderer>().bounds.size;

            if (size.x <= radius * 2f && size.y <= radius * 2f)
                fontSize++;
            else
                break;
        }

        return fontSize;
    }
    private void isWinner()
    {
        updatedNames.Clear();
        foreach (var circle in circlesList)
            {
                //Debug.Log($"Circle: {circle.circleName}, Starting Angle: {circle.startingAngle}, Ending Angle: {circle.endingAngle}");
               // i++;
               circle.startingAngle+=totalAngleRotated;
               circle.endingAngle+=totalAngleRotated;
               
               float divisor=360F;
               circle.startingAngle%=divisor;
               circle.endingAngle%=divisor;

             Debug.Log($"Circle: {circle.circleName}, Starting Angle: {circle.startingAngle}, Ending Angle: {circle.endingAngle}");
               //if(circle.endingAngle>=90 && circle.startingAngle>=270)
                if(circle.startingAngle<=90 && circle.endingAngle>90 || circle.endingAngle>=90 && circle.startingAngle>=270 && circle.startingAngle>circle.endingAngle)
                {
                    Debug.Log("Winner is ="+circle.circleName);
                }
                else
                {
                    updatedNames.Add(circle.circleName);
                }
            }
            //PrintNames(updatedNames);
            //DestroyCreatedObjects();
            //ClearSegments();
            WriteToJSON();
            
            //Start();//LOAD SCENE
            StartCoroutine(WaitForOneSecond());   
            //string currentSceneName = SceneManager.GetActiveScene().name;
            //SceneManager.LoadScene(currentSceneName);         
    }
    private IEnumerator WaitForOneSecond()
    {
        //Debug.Log("Coroutine 10secc started");
        yield return new WaitForSeconds(1f);

        DestroyCreatedObjects();
        ClearSegments();
        string currentSceneName = SceneManager.GetActiveScene().name;
        SceneManager.LoadScene(currentSceneName);  
    }
    static void PrintNames(List<string> names)
    {
        foreach (string name in names)
        {
            Debug.Log(name);
        }
    }
    public void ClearSegments()
    {
        // Destroy all child objects (segments and text)
        int childCount = transform.childCount;
        for (int i = childCount - 1; i >= 0; i--)
        {
            Transform child = transform.GetChild(i);
            Destroy(child.gameObject);
        }
    }
    private void DestroyCreatedObjects()
    {
        foreach (var circle in circlesList)
        {
            GameObject segmentObject = GameObject.Find(circle.circleName); // Assuming the circle name is unique
            if (segmentObject != null)
            {
                Destroy(segmentObject);
            }
        }
        
        // Clear the circlesList to remove all references
        circlesList.Clear();
    }
    public void  WriteToJSON()   
    {
        Names nameData1 = new Names();
        nameData1.names = updatedNames.ToArray();
        string jsonString = JsonUtility.ToJson(nameData1);
        string filePath = Application.persistentDataPath + "/names.json";
        if (System.IO.File.Exists(filePath))
        {
            System.IO.File.Delete(filePath);
        }        
        filePath = Application.persistentDataPath + "/names.json";
        System.IO.File.WriteAllText(filePath, jsonString);

    }
    public void playAgain()
    {
        //Canvas.SetActive(false);
        SceneManager.LoadScene("InputNames");  
    }
}
