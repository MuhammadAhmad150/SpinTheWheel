using UnityEngine;
using System.Collections.Generic;
using System.Collections;
using System.IO;
using System;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


[System.Serializable]
public class NameData
{
    public string[] names;
}

public class Reader : MonoBehaviour
{
    public InputField inputField1;
        public List<string> stringList = new List<string>();
        // List<string> namesList = new List<string>
        // {
        //     "M.A",
        //     "Zahra",
        //     "786",
        //     "SUHAIL",
        //     "Izza"

        // };
    void Start()
    {
        if(!inputField1.multiLine )
        {
            inputField1.lineType = InputField.LineType.MultiLineNewline;
            Debug.Log("The main input field is now set to allow MultiLINE lines only!");
        }
    }
    // void Start()
    // {
    //     // Convert the list of names to a NameData instance
    //     NameData nameData = new NameData();
    //     nameData.names = namesList.ToArray();

    //     // Convert the NameData instance to a JSON string
    //     string jsonString = JsonUtility.ToJson(nameData);

    //     // Write the JSON string to a file (optional)
    //     string filePath = Application.persistentDataPath + "/names.json";
    //     System.IO.File.WriteAllText(filePath, jsonString);

    //     // Deserialize the JSON string back into a NameData instance (optional)
    //     NameData deserializedNameData = JsonUtility.FromJson<NameData>(jsonString);

    //     // Print the deserialized names to the console
    //     //foreach (string name in deserializedNameData.names)
    //     {
    //        // Debug.Log("Deserialized Name: " + name);
    //     }
    // }

    public void buttonPressed()
    {
        stringList.Clear();

        string inputText = inputField1.text;
        string[] elements = inputText.Split('\n');
        for (int i = 0; i < elements.Length; i++)
        {
            elements[i] = elements[i].Trim();
        }
        stringList.AddRange(elements);
        //PRINTPRINTT786
        foreach (string element in stringList)
        {
            Debug.Log(element);
        }
        //stringList to persistent
        writeToJSON();

        // Debug.Log("Data List Contents:");
        // foreach (string data in namesList)
        // {
        //     //Debug.Log(data);
        // }
        SceneManager.LoadScene("SampleScene");  
    }
    public void  writeToJSON()   
    {
        NameData nameData1 = new NameData();
        nameData1.names = stringList.ToArray();
        string jsonString = JsonUtility.ToJson(nameData1);
        string filePath = Application.persistentDataPath + "/names.json";
        System.IO.File.WriteAllText(filePath, jsonString);

    }
}

